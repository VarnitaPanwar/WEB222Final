// Attach reviewData to the global window Object
// so other scripts can access it at runtime.
window.reviewData = [
    {
        name: "Gerry",
        date: "2023-04-08",
        rating: 4,
        review: "Ludo is a highly entertaining game that combines strategy and skill, making it a fun choice to play with friends. I always relish the experience of playing this game with my peers"
    },
    {
        name: "Ram",
        date: "2022-04-08",
        rating: 5,
        review: "I love Ludo! It's a classic game that's always a hit with my family. It's easy to learn and play, but it still requires strategy and skill to win. I highly recommend it!"
    },
    {
        name: "",
        date: "2023-04-10",
        rating: 4,
        review: "I've been playing Ludo for years, and it never gets old. The game is simple yet challenging, and it's a great way to spend time with family and friends. I highly recommend it to anyone looking for a fun and engaging board game"
    },
    {
        name: "Anju",
        date: "2023-04-11",
        rating: 5,
        review: "Ludo is a game that requires both luck and skill. It's always thrilling to roll the dice and see where your pieces will land. I love the competitive nature of the game, and I highly recommend it to anyone who enjoys playing board games."
    },
    {
        name: "David",
        date: "2023-04-11",
        rating: 3,
        review: "Ludo is a great game to play with kids, but as an adult, it can be a bit too simple for my taste. I prefer games that are more challenging and require more strategic thinking."
    }
];
